﻿namespace IPGTest.Models
{
    public class Item
    {
        public int Id { get; set; }

        public int LotNumber { get; set; }

        public int SequenceNumber { get; set; }

        public int BoxId { get; set; }
    }
}
