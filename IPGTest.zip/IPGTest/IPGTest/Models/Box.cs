﻿namespace IPGTest.Models
{
    public class Box
    {
        public int Id { get; set; }

        public string? Name { get; set; }
    }
}
